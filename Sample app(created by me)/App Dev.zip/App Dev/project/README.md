# exploration_planner

A new Flutter project used to accurately and completely explore space. Some of the statements in the previous sentence may not be completely true.

# Companion Videos

This project is a companion to a set of videos on the Flutter Dev YouTube channel. The first in the series starts with ["How do I make my first Flutter app."](https://www.youtube.com/watch?v=xWV71C2kp38)

For more help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
